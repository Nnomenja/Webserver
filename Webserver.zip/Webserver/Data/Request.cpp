#include "Request.hpp"
#include "../Core/HTTP/Request/RequestParserState/MethodParser.hpp"
#include "../Core/HTTP/Request/RequestParserState/ARequestParserState.hpp"

#include <algorithm>

Request::Request():_index(0), _parserState(NULL), _method(GET){

};

Request::Request(const Request& other){
  std::cout << "Copy" << std::endl;
  *this = other; 
};

Request& Request::operator=(const Request& other){
  std::cout << "Copy assignment" << std::endl;
  if (this != &other) {
  }
  return *this;
};

Request::~Request(){
	delete _parserState;
};

/**============================================
 *               GETTERS
 *=============================================**/

ARequestParserState *Request::getParserState() const
{
  return (_parserState);
}

size_t Request::getParserIndex() const
{
	return (_index);
}

std::string Request::getBuffer() const
{
  return (_buffer);
}

size_t Request::getBufferSize() const
{
	return (_buffer_size);
}

HttpMethod Request::getMethod() const
{
	return (_method);
}


const std::string &Request::getPathname() const
{
	return (_pathname);
}


std::string Request::getQuery() const
{
	return (_query);
}

std::map<std::string, std::string> Request::getHeaders() const
{
	return (_headers);
}


const std::string &Request::getHeaderBykey(std::string key)
{
	return (_headers[key]);	
}

t_body_encode Request::getBodyEncode() const
{
	return (_body_encode);
}

long Request::getContentLength() const
{
	return (_contentLength);
}

const std::string &Request::getBody() const
{
	return (_body);
}

t_location Request::getLocation() const
{
	return (_location);
}


const std::string &Request::getLocationDefaultIndex() const
{
	return (_location.index);
}

std::string Request::getFullPath() const
{
	return (_fullpath);
}

std::string Request::getRootDir() const
{
	if (_location.root.empty())
		return (_root);
	return (_location.root);
}

/**============================================
 *               SETTERS
 *=============================================**/

void Request::incrementParserIndex()
{
	_index++;
}
void Request::resetParserIndex()
{
	_index = 0;
}

void Request::setParseState(ARequestParserState *state)
{
	if (_parserState)
		delete _parserState;
    _parserState = state;
}
void Request::setBuffer(std::string &value)
{
	_buffer = value;
	_buffer_size = value.size();
}


void Request::setMethod(HttpMethod value)
{
	_method = value;
}

void Request::setPathname(std::string value)
{
	_pathname = value;
}

void Request::setFullPath(std::string value)
{
	_fullpath = value;
}

void Request::setRoot(std::string value)
{
	_root = value;
}

void Request::addPathname(char c)
{
	_pathname.push_back(c);
}

void Request::addQuery(char c)
{
	_query.push_back(c);
}

std::string &Request::toLowerCase(std::string &src) const
{
	std::transform(src.begin(), src.end(), src.begin(), ::tolower);
	return (src);
}

void Request::setHeader(std::string key, std::string value)
{
	_headers[toLowerCase(key)] = value;
}

bool Request::hasHeader(std::string value) const
{
	return (_headers.find(value) != _headers.end());
}

void Request::setContenLength(long value)
{
	_contentLength = value;
}

void Request::setBodyEncode(t_body_encode value)
{
	_body_encode = value;
}

void Request::addBody(char c)
{
	_body.push_back(c);
}

void Request::setLocation(t_location &value)
{
	_location = value;
}
void Request::setLocationType(LocationType value)
{
	_location.type = value;
}
void Request::setRedirectionPath(std::string &value)
{
	_location.return_path = value;
}