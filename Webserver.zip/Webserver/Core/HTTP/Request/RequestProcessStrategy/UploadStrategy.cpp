/*
   File: UploadStrategy.cpp
   By: Azaria
   Created: 2026/04/08 16:15:17
*/

# include <iostream>
# include <algorithm>

#include "UploadStrategy.hpp"
#include "../../../../Exception/MethodNotAllowed.hpp"
#include "../../../../Exception/BadRequestException.hpp"
#include "../../../../Exception/UnsupportedMediaType.hpp"


UploadStrategy::UploadStrategy()
{ }

UploadStrategy::~UploadStrategy()
{ }

void responseData(Response *response)
{
    std::string body = 
        "<!DOCTYPE html>"
        "<html lang=\"fr\">"
        "<head>"
        "<meta charset=\"UTF-8\">"
        "<title>Webserv - 42 Antananarivo</title>"
        "<style>"
        "body{margin:0;padding:0;background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);"
        "font-family:Arial,sans-serif;color:white;display:flex;justify-content:center;"
        "align-items:center;height:100vh;}"
        ".card{background:rgba(255,255,255,0.1);backdrop-filter:blur(10px);"
        "padding:40px;border-radius:15px;text-align:center;"
        "box-shadow:0 0 30px rgba(0,0,0,0.5);width:500px;}"
        "h1{margin-bottom:10px;font-size:32px;}"
        ".status{color:#22c55e;font-weight:bold;font-size:20px;}"
        ".info{margin-top:20px;font-size:14px;opacity:0.85;}"
        ".footer{margin-top:30px;font-size:12px;opacity:0.6;}"
        "</style>"
        "</head>"
        "<body>"
        "<div class=\"card\">"
        "<h1>Webserv Opérationnel</h1>"
        "<div class=\"status\">HTTP/1.1 200 OK</div>"
        "<div class=\"info\">"
        "<p>Projet: Webserv</p>"
        "<p>Langage: C++98</p>"
        "<p>Architecture: epoll event-driven</p>"
        "<p>Mode: Non-Blocking I/O</p>"
        "</div>"
        "<div class=\"footer\">42 Antananarivo - 2026</div>"
        "</div>"
        "</body>"
        "</html>";

        std::ostringstream oss;
        oss << body.size();
        
        response->setStatusCode(200);
        response->setStatusName("OK");

        response->addHeader("Content-Type", "text/html; charset=UTF-8");
        response->addHeader("Connection", "close");
        response->addHeader("Content-Length", oss.str());
        response->setBody(body);
}


void simulBodyData(BodyType type, Request* request)
{
    switch (type)
    {
        case NONE:
            request->setContentType("");
            request->setBody("");
            break;
      
        case DIRECT:
            request->setContentType("text/plain");
            request->setBody("Ligne 1 du contenu direct\nLigne 2\nLigne 3 avec des données: ABC123!@#");
            // Pour simuler du binaire, on peut mettre des bytes non imprimables
            break;
        
        case MULTIPART:
            request->setContentType("multipart/form-data");
            request->setContentTypeParam("boundary", "boundary123");
            
            request->setBody(
                "--boundary123\r\n"
                "Content-Disposition: form-data; name=\"text_field\"\r\n"
                "\r\n"
                "Valeur simple\r\n"
                "--boundary123\r\n"
                "Content-Disposition: form-data; name=\"file1\"; filename=\"test1.txt\"\r\n"
                "Content-Type: text/plain\r\n"
                "\r\n"
                "Contenu du premier fichier\r\n"
                "--boundary123\r\n"
                "Content-Disposition: form-data; name=\"file2\"; filename=\"test2.sh\"\r\n"
                "Content-Type: application/x-sh\r\n"
                "\r\n"
                "#!/bin/bash\necho \"Hello from script\"\r\n"
                "--boundary123\r\n"
                "Content-Disposition: form-data; name=\"json_data\"\r\n"
                "Content-Type: application/json\r\n"
                "\r\n"
                "{\"key\":\"value\",\"number\":42}\r\n"
                "--boundary123--\r\n"
            );
            break;
        
        case URLENCODED:
            request->setContentType("application/x-www-form-urlencoded");
            
            request->setBody(
                "name=John%20Doe&"
                "email=john%40example.com&"
                "age=30&"
                "interests=coding%2Creading%2Cgaming&"
                "comment=Hello%20world%21&"
                "newsletter=true&"
                "file=data.txt"
            );
            break;
            
        default:
            break;
    }
}

void UploadStrategy::process(Client *client)
{
    Request     *request = client->getRequest();
    // Response    *response = client->getResponse();


    if (request->getMethod() != POST 
        && request->getMethod() != GET
        && request->getMethod() != DELETE
    )
    {
        throw MethodNotAllowed();
    }

    {
        simulBodyData(DIRECT, request);
    }

    BodyType bodyType = bodyTypeDetection(request);

    switch (bodyType)
    {
        case DIRECT:
            return handleDirectUpload();

        // case MULTIPART:
        //     return handleMultipartUpload();

        // case URLENCODED:
        //     return handleUrlEncoded();

        default:
            throw UnsupportedMediaType();
    }
}

BodyType UploadStrategy::bodyTypeDetection(Request* request)
{
    if (request->getBody().empty() && request->getContentLength() == 0) {
        return NONE;
    }

    std::string contentType = request->getContentType();
    std::transform(contentType.begin(), contentType.end(),
                   contentType.begin(), ::tolower);

    // Multipart standard (multipart/form-data, multipart/mixed, ...)
    if (contentType.find("multipart/") == 0) {
        std::string boundary = request->getContentTypeParam("boundary");
        if (boundary.empty())
        {
            throw BadRequestException();
        }

        return MULTIPART;
    }

    // URL-encoded : AVANT le bloc application/* générique
    if (contentType == "application/x-www-form-urlencoded") {
        return URLENCODED;
    }

    // octet-stream : binaire brut OU multipart binaire selon boundary
    if (contentType == "application/octet-stream") {
        std::string boundary = request->getContentTypeParam("boundary");
        return boundary.empty() ? DIRECT : MULTIPART;
    }

    // Types connus → envoi direct du corps brut
    if (contentType.find("text/")        == 0 ||
        contentType.find("application/") == 0 ||
        contentType.find("image/")       == 0 ||
        contentType.find("video/")       == 0 ||
        contentType.find("audio/")       == 0) {
        return DIRECT;
    }

    // Pas de Content-Type mais un corps présent → direct par défaut
    if (contentType.empty() && !request->getBody().empty()) {
        return DIRECT;
    }

    return UNKNOWN;
}


std::string UploadStrategy::creatUploadFileName(Request* request)
{
    std::string filename;

    // ─── 1) Cherche filename dans multipart header ───────────────────────────
    if (filename.empty()) { 
        filename = request->getMultipartFilename(); // Content-Disposition: form-data; filename="..."
    }

    // ─── 2) Sinon cherche header custom ─────────────────────────────────────
    if (filename.empty()) {
        filename = request->getHeader("X-Filename");
    }
    if (filename.empty()) {
        filename = request->getHeader("X-File-Name");
    }

    // ─── 3) Sinon applique règle de route ────────────────────────────────────
    if (filename.empty()) {
        filename = request->getRouteParam("upload_filename");
    }

    // ─── 4) Sinon génère nom automatique ─────────────────────────────────────
    if (filename.empty()) {
        std::string ext = "";

        // Deviner l'extension depuis le Content-Type
        std::string contentType = request->getContentType();
        std::transform(contentType.begin(), contentType.end(),
                       contentType.begin(), ::tolower);

        if      (contentType.find("image/jpeg") != std::string::npos) ext = ".jpg";
        else if (contentType.find("image/png")  != std::string::npos) ext = ".png";
        else if (contentType.find("image/gif")  != std::string::npos) ext = ".gif";
        else if (contentType.find("image/webp") != std::string::npos) ext = ".webp";
        else if (contentType.find("video/mp4")  != std::string::npos) ext = ".mp4";
        else if (contentType.find("audio/mpeg") != std::string::npos) ext = ".mp3";
        else if (contentType.find("application/pdf") != std::string::npos) ext = ".pdf";
        else if (contentType.find("text/plain") != std::string::npos) ext = ".txt";

        // Timestamp + random pour unicité garantie
        std::ostringstream oss;
        std::time_t now = std::time(nullptr);
        oss << "upload_" << now << "_" << (std::rand() % 9000 + 1000) << ext;
        filename = oss.str();
    }

    // ─── 5) Nettoie le nom (sécurité) ────────────────────────────────────────
    {
        // Supprime path traversal : ../../etc/passwd → etcpasswd
        std::string cleaned;
        cleaned.reserve(filename.size());
        for (size_t i = 0; i < filename.size(); ++i) {
            char c = filename[i];
            if (c == '/' || c == '\\' || c == '\0') continue;  // séparateurs interdits
            if (c == '.' && i + 1 < filename.size() && filename[i+1] == '.') continue; // ..
            cleaned += c;
        }
        filename = cleaned;

        // Remplace les espaces et caractères spéciaux par '_'
        for (size_t i = 0; i < filename.size(); ++i) {
            char c = filename[i];
            if (!std::isalnum(c) && c != '.' && c != '-' && c != '_') {
                filename[i] = '_';
            }
        }

        // Limite la longueur (255 max filesystem)
        if (filename.size() > 200) {
            std::string ext = "";
            size_t dot = filename.rfind('.');
            if (dot != std::string::npos) {
                ext = filename.substr(dot); // garde l'extension
            }
            filename = filename.substr(0, 200 - ext.size()) + ext;
        }
    }

    // ─── 6) Vérifie validité ──────────────────────────────────────────────────
    if (filename.empty() || filename == "." || filename == "..") {
        // Nom invalide après nettoyage → fallback automatique
        std::ostringstream oss;
        std::time_t now = std::time(nullptr);
        oss << "upload_" << now << "_" << (std::rand() % 9000 + 1000);
        filename = oss.str();
    }

    // ─── 7) Ajoute dossier upload ─────────────────────────────────────────────
    std::string uploadDir = request->getRouteParam("upload_dir");
    if (uploadDir.empty()) {
        uploadDir = "./uploads"; // dossier par défaut
    }
    // S'assure que le dossier se termine par '/'
    if (uploadDir[uploadDir.size() - 1] != '/') {
        uploadDir += '/';
    }

    // Crée le dossier si inexistant
    struct stat st;
    if (stat(uploadDir.c_str(), &st) != 0) {
        mkdir(uploadDir.c_str(), 0755);
    }

    // ─── 8) Gère collision ────────────────────────────────────────────────────
    std::string fullPath = uploadDir + filename;

    if (stat(fullPath.c_str(), &st) == 0) {
        // Fichier existe déjà → insère un compteur avant l'extension
        std::string base = filename;
        std::string ext  = "";

        size_t dot = filename.rfind('.');
        if (dot != std::string::npos) {
            base = filename.substr(0, dot);
            ext  = filename.substr(dot);
        }

        int counter = 1;
        do {
            std::ostringstream oss;
            oss << uploadDir << base << "_" << counter << ext;
            fullPath = oss.str();
            counter++;
        } while (stat(fullPath.c_str(), &st) == 0 && counter < 10000);
    }

    // ─── 9) Retourne chemin final ─────────────────────────────────────────────
    return fullPath;
}


void UploadStrategy::handleDirectUpload(Client* client)
{


    Request     *request = client->getRequest();

    request.get

    std::string fileName;
    std::string path;

    std::ofstream file(path.c_str(), std::ios::binary);
    if (!file.is_open())
        return false;

    char buffer[8192];
    size_t totalRead = 0;

    while (totalRead < contentLength)
    {
        ssize_t bytes = recv(clientFd, buffer, sizeof(buffer), 0);
        if (bytes <= 0)
            return false;

        file.write(buffer, bytes);
        totalRead += bytes;
    }

    file.close();
    return true;
    // Response    *response = client->getResponse();
}
    