/*
   File: UploadStrategy.hpp
   By: Azaria
   Created: 2026/04/08 16:13:50
*/

#ifndef UPLOADSTRATEGY_HPP
#define UPLOADSTRATEGY_HPP

# include "IRequestStrategy.hpp"
#include "../../../../Data/Client.hpp"
#include "../../../../Data/Request.hpp"

enum BodyType
{
    NONE,
    DIRECT,
    MULTIPART,
    URLENCODED,
    UNKNOWN
};

class UploadStrategy : public IRequestStrategy
{
    public :
        UploadStrategy();
        ~UploadStrategy();

        void process(Client* client);

    private :

        BodyType bodyTypeDetection(Request* request);
        void     handleDirectUpload(Client* client);
        std::string creatUploadFileName(Request* request);
};

#endif /* UPLOADSTRATEGY_HPP */

